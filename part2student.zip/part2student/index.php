<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
 <link rel="stylesheet" href="css/menu2.css">
 	<!-- Bootstrap Core CSS -->
   <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <title>Page d'accueil</title>

</head>

<body style="background-color:green;">

          <div>

          </div>
          <br> <br>
          <div class="card-group">
            <div class="card">
            <a href="register.php"> <img src="img/Registration.png" class="card-img-top" alt="..."></a>
              <div class="card-body">
                <h5 class="card-title">INSCRIVEZ VOUS </h5>
                <p>Veillez cliquez ici pour vous inscrire </p>
              </div>
            </div>
            <div class="card">
              
              <a href="signe.php" ><img src="img/signature.JPG" class="card-img-top" alt="..."> </a>
              <div class="card-body">
                <h5 class="card-title">SIGNEZ VOTRE PRESENCE </h5>
                <p >Si vous êtes déja inscrit, alors signé votre presence en salle </p>
              </div>
            </div>
            <div class="card">
              
              <a href="prof.php"><img src="img/dashbord.PNG" class="card-img-top" alt="..."></a>
              <div class="card-body">
                <h5 class="card-title">Espace professeur </h5>
                <p> le tableu de bord du professeur.</p>
              </div>
            </div>
          </div>

</BOdy>

</HTml>