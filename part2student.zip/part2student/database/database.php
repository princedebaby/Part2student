<?php

	$servername = "localhost";
	$username = "root";
	$password = "";
	$db="dbstudent";

	$conn = mysqli_connect($servername, $username, $password, $db);
?>