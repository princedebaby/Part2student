<?php
session_start();	
?>

<html>
	<head>
    <title>Page d'administration</title>		
		<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
		<!-- Custom fonts for this template-->
		 <!-- Custom fonts for this template-->
		 <link href="css/all.min.css" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		<!-- Custom styles for this template-->
		<link href="css/sb-admin-2.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link href="css/style3.css" rel="stylesheet">
		

		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
		<!-- Bootstrap Core CSS -->
		<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

		<!-- Custom Fonts -->
		<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
		<link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

		<!-- Custom CSS -->
		<link href="css/stylish-portfolio.min.css" rel="stylesheet">

		</head>

		<body id="page-top">

    <?php
    include "database/database.php";
    $email=$_SESSION['email'];
    $check=mysqli_query($conn,"select * from student_table where email='$email'");
    $name="";
    if (mysqli_num_rows($check)>0)
    {
        $row = mysqli_fetch_assoc($check);
        $idUser = $row['id'];
        $image=$row['image'];

        $name = $row["name"];   }
    
    ?>
		<!-- Navigation -->
		<a class="menu-toggle rounded" href="#">
		<i class="fas fa-bars"></i>
		</a>
		<nav id="sidebar-wrapper" style="background-color: green;">
		<ul class="sidebar-nav">
			<li class="sidebar-brand">
			<a class="js-scroll-trigger" href="#page-top">Menu</a>
			</li>
			<li class="sidebar-nav-item">
			<a class="js-scroll-trigger" href="dashbord_student.php">Accueil</a>
			</li>
			<li class="sidebar-nav-item">
			<a class="js-scroll-trigger" href="logout.php">Deconnecter</a>
			</li>
		</ul>
		</nav>

		<!-- Bootstrap core JavaScript -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

		<!-- Plugin JavaScript -->
		<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

		<!-- Custom scripts for this template -->
		<script src="js/stylish-portfolio.min.js"></script>

        <nav class="navbar navbar-expand-lg navbar-light bg-light " style="size: 20px;">
        <a class="navbar-brand" href="daschbord_student.php"><img width="40" height="40" src="<?=$image?>"><?=$name?>| </a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
    </button>
		<a class="navbar-brand" href="daschbord_student.php">Accueil</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<a class="navbar-brand" href="logout.php">Deconnecter</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		

	</nav>



    <!-- <div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="#">HTML</a></li>
    <li><a href="#">CSS</a></li>
    <li><a href="#">JavaScript</a></li>
  </ul>
</div> -->


    <div class="demo-content">
    <br/><br/><br/>
        <div class="row"align="center">
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="signe.php">
        <img src="signe.jpg" alt="Lights" style="width:100%">
        <div class="caption">
          <p><h5>Signer</h5></p>
        </div>
      </a>
    </div>
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="profile.php">
        <img src="" alt="Nature" style="width:100%">
        <div class="caption">
        <p><h5>Profil</h5></p>
        </div>
      </a>
    </div>
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="graph.php">
        <img src="" alt="Fjords" style="width:100%">
        <div class="caption">
        <p><h5>Graph</h5></p>
        </div>
      </a>
    </div>
  </div>
</div>
       
	
  </div>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
</body></html>
