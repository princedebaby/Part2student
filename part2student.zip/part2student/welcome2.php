<?php
session_start();
include 'database/database.php'; 
?>

<!DOCTYPE html>

<html>

<head>
   
    <meta charset="utf-8" />
    <title>Titre</title>
    <title>ESPACE ADMINISTRATION</title>
  
  <!-- Custom fonts for this template-->
  <link href="css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
    
</head>

<body>
    <h1><font color="green">Felicitation</font> vous avez signé aujourd'hui <font color="red"> <?php echo " le " . date('d-m-Y') . " à " . date('H:i:s') ?> </h1><br><br><br> </font>

    <div class="mx-auto" style="width: 200px;">
        <a href="logout.php" class="btn btn-primary"> OK </a>
    </div>


    <?php
    $email = $_SESSION["email"];
    $dup = mysqli_query($conn, "SELECT id, from student_table where email='$email'");
    $row = mysqli_fetch_assoc($dup);
    $id = $row["id"];

    echo "votre id est $id ";
    $date = date("Y-m-d");
  $verif = mysqli_query($conn,"SELECT id,iduser,datesign FROM attendance_table WHERE iduser='$id' AND datesign='$date'");   
 
  
  if(mysqli_num_rows($verif)==0){
    
  $insertion = "INSERT INTO attendance_table (iduser) VALUES('$id',)";
  mysqli_query($conn, $insertion);
  echo "information bien rentrer"; 
 }
  else
  {
      echo " vous avez deja signer";
  }

    ?>



</body>

</html>