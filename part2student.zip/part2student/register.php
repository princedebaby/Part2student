<?php
session_start();
include 'database/database.php'; 







// If file upload form is submitted 
$status = $statusMsg = '';
if (isset($_POST['save'])) {
$email=$_POST['email'];


$verif = mysqli_query($conn,"select * from student_table where email = '$email'");
if (mysqli_num_rows($verif)==0) {
    $status = 'error';
    $path = 'profil/'; // Repertoire de telechargement
    if (!empty($_FILES["file"]["name"])) {
        // Obtention information sur le fichier
        $fileName = basename($_FILES["file"]["name"]);
        $ext = $_FILES['file']['tmp_name'];

        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // On peut télécharger la même image en utilisant la rand function
        $final_image = rand(1000, 1000000) . $fileName;

        // Autoriser certains formats d'images
        $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
        if (in_array($fileType, $allowTypes)) {
            $path = $path . strtolower($final_image);// variable du chemin de l image

            if (move_uploaded_file($ext, $path)) {
                $name = htmlspecialchars($_POST['name']);
                $email = htmlspecialchars($_POST['email']);
                $telephone = htmlspecialchars($_POST['telephone']);
                $password = htmlspecialchars(md5($_POST['password']));// crypter le mot de passe
                $sexe = $_POST['sexe'];

                // Insertion des données dans la base de données
                $insert = mysqli_query($conn, "INSERT into student_table (name, email, password, telephone, sexe ,image)
						VALUES ('$name','$email','$password','$telephone','$sexe','$path')");

                if ($insert) {
					$status = 'success';
				
                    header('Location: signe.php');
                } else {
                    echo  'Echec du téléchargement, Veuillez reprendre votre telechargement svp.';
                }
            } else {
                echo 'Désolé, seul les types JPG, JPEG, PNG, & GIF sont autorisés.';
            }
        } else {
            echo  'selectionner une image à télécharger.';
        }
	}
} else{
	echo"
	<h1><font color='green'>Vous etes deja incris</font></h1><br>
	<a href='signe.php'>Retour</a>

	";
}

	mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Page d'inscription</title>
    <link rel="stylesheet" type="text/css" href="css/styleinsc.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body  style="background-color:green;">

<nav class="navbar navbar-expand-lg navbar-light bg-light" style="size: 20px;">
  <a class="navbar-brand" href="index.php">Accueil</a>
</nav>

  
<div class="FormInscris">
            <div class="form-saisie" style="color:white">

                    <form id="register_form" method="post" enctype="multipart/form-data"  onsubmit="return checkall();">
                     
                        <label for="email">Name:</label>
                        <input type="text" class="form-control" id="name" placeholder="Name" name="name">


                        <label for="pwd">Email:</label>
                        <input type="email" class="form-control" id="email" placeholder="Email" name="email" required onkeyup="checkemail();">
                        <span id="email_status"></span>


                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Votre mot de passe" required maxlength="10">


                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="password2" name="password2" placeholder="Confirmez votre password" required maxlength="10" onkeyup="checkpass();">
                        <span id="pass_status"></span>


                        <label for="telephone">Telephone:</label>
                        <input type="tel" class="form-control" id="telephone" placeholder="telephone" name="telephone" required onkeyup="checktelephone();">
                        <span id="telephone_status"></span>


                        <input type="radio" name="sexe" id="agree-term" class="agree-term" value="homme" checked />
                        <label for="agree-term" class="label-agree-term">homme</label>

                        <input type="radio" name="sexe" id="agree-term" class="agree-term" value="femme" />
                        <label for="agree-term" class="label-agree-term">Femme</label>

                        <input type="radio" name="sexe" id="agree-term" class="agree-term" value="autre" />
                        <label for="agree-term" class="label-agree-term">Autre</label>


                        <input type="file" class="form-control" id="img" placeholder="image" name="file">


                        <input type="submit" name="save" class="btn btn-primary" value="Valider" style="background-color: green;"><br><br>
					Vous avez déjà un compte?&nbsp;<a href="signe.php">Cliquez ici</a>
    
                    </form>
            </div>
        </div>
    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>

    <script>
        function checktelephone() //Fonction qui vérifie si le téléphone existe ou pas
        {
            var telephone = document.getElementById("telephone").value;

            if (telephone) {
                $.ajax({
                    type: 'post',
                    url: 'auth.php',
                    data: {
                        telephone: telephone,
                    },
                    success: function(response) {
                        $('#telephone_status').html(response);
                        if (response == "juste") {
                            return true;
                        } else {
                            return false;
                        }
                    }
                });
            } else {
                $('#phone_status').html("");
                return false;
            }
        }

        function checkemail() //Fonction qui vérifie si le mail existe ou pas
        {
            var email = document.getElementById("email").value;

            if (email) {
                $.ajax({
                    type: 'post',
                    url: 'auth.php',
                    data: {
                        email: email,
                    },
                    success: function(response) {
                        $('#email_status').html(response);
                        if (response == "juste") {
                            return true;
                        } else {
                            return false;
                        }
                    }
                });
            } else {
                $('#email_status').html("");
                return false;
            }
        }

        function checkpass() //Fonction qui vérifie si les mMdp correspondent
        {
            var password2 = document.getElementById("password2").value;
            var password = document.getElementById("password").value;

            if (password2) {
                $.ajax({
                    type: 'post',
                    url: 'auth.php',
                    data: {
                        password2: password2,
                        password: password,
                    },
                    success: function(response) {
                        $('#pass_status').html(response);
                        if (response == "juste") {
                            return true;
                        } else {
                            return false;
                        }
                    }
                });
            } else {
                $('#pass_status').html("");
                return false;
            }
        }
        // Verification de tous les informations 

        function checkall() {
            var phonehtml = document.getElementById("phone_status").innerHTML;
            var emailhtml = document.getElementById("email_status").innerHTML;
            var passhtml = document.getElementById("pass_status").innerHTML;

            if ((phonehtml && emailhtml && passhtml) == "juste") {
                return true; //On peut s'inscrire
            } else {
                return false; //On ne peut pas s'incrire
            }
        }
    </script>
</body>

</html>